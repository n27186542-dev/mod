package com.example.oceanworld;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.util.KeyDispatchDataCodec;
import net.minecraft.world.level.levelgen.DensityFunction;

/**
 * Distance in blocks from the centre line of the strip (same angle as StripMask).
 * Used to keep islands far away from the strip.
 */
public record StripDistance(double angleDegrees) implements DensityFunction.SimpleFunction {

    public static final MapCodec<StripDistance> CODEC = RecordCodecBuilder.mapCodec(i -> i.group(
            Codec.doubleRange(-90.0, 90.0).optionalFieldOf("angle_degrees", 0.0).forGetter(StripDistance::angleDegrees)
    ).apply(i, StripDistance::new));

    public static final KeyDispatchDataCodec<StripDistance> KEY_CODEC = KeyDispatchDataCodec.of(CODEC);

    @Override
    public double compute(FunctionContext ctx) {
        double a = Math.toRadians(angleDegrees);
        return Math.abs(-Math.sin(a) * ctx.blockX() + Math.cos(a) * ctx.blockZ());
    }

    @Override
    public double minValue() { return 0.0; }

    @Override
    public double maxValue() { return 1.0E8; }

    @Override
    public KeyDispatchDataCodec<? extends DensityFunction> codec() { return KEY_CODEC; }
}
