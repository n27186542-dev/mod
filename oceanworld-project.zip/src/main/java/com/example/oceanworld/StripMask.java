package com.example.oceanworld;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.util.KeyDispatchDataCodec;
import net.minecraft.world.level.levelgen.DensityFunction;

/**
 * Mask of a straight land strip tilted by angle_degrees: 1.0 inside the strip,
 * smoothly falling to 0.0 outside.
 * half_width = distance from the centre line to the edge (perpendicular, in blocks).
 * falloff = number of blocks over which the mask fades (coast / shallows).
 * angle_degrees = tilt of the strip relative to the X axis (0 = along X).
 */
public record StripMask(int halfWidth, int falloff, double angleDegrees) implements DensityFunction.SimpleFunction {

    public static final MapCodec<StripMask> CODEC = RecordCodecBuilder.mapCodec(i -> i.group(
            Codec.intRange(1, 100000).fieldOf("half_width").forGetter(StripMask::halfWidth),
            Codec.intRange(1, 100000).fieldOf("falloff").forGetter(StripMask::falloff),
            Codec.doubleRange(-90.0, 90.0).optionalFieldOf("angle_degrees", 0.0).forGetter(StripMask::angleDegrees)
    ).apply(i, StripMask::new));

    public static final KeyDispatchDataCodec<StripMask> KEY_CODEC = KeyDispatchDataCodec.of(CODEC);

    @Override
    public double compute(FunctionContext ctx) {
        double a = Math.toRadians(angleDegrees);
        double dist = Math.abs(-Math.sin(a) * ctx.blockX() + Math.cos(a) * ctx.blockZ());
        double d = dist - halfWidth;
        if (d <= 0) return 1.0;
        double t = Math.max(0.0, 1.0 - d / falloff);
        return t * t * (3 - 2 * t);
    }

    @Override
    public double minValue() { return 0.0; }

    @Override
    public double maxValue() { return 1.0; }

    @Override
    public KeyDispatchDataCodec<? extends DensityFunction> codec() { return KEY_CODEC; }
}
