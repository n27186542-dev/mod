package com.example.oceanworld;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.util.KeyDispatchDataCodec;
import net.minecraft.world.level.levelgen.DensityFunction;

/**
 * Perpendicular distance in blocks from the centre line of the strip.
 * signed = false: always >= 0. signed = true: negative on one side, positive on the other.
 */
public record StripDistance(double angleDegrees, boolean signed) implements DensityFunction.SimpleFunction {

    public static final MapCodec<StripDistance> CODEC = RecordCodecBuilder.mapCodec(i -> i.group(
            Codec.doubleRange(-90.0, 90.0).optionalFieldOf("angle_degrees", 0.0).forGetter(StripDistance::angleDegrees),
            Codec.BOOL.optionalFieldOf("signed", false).forGetter(StripDistance::signed)
    ).apply(i, StripDistance::new));

    public static final KeyDispatchDataCodec<StripDistance> KEY_CODEC = KeyDispatchDataCodec.of(CODEC);

    @Override
    public double compute(FunctionContext ctx) {
        double a = Math.toRadians(angleDegrees);
        double v = -Math.sin(a) * ctx.blockX() + Math.cos(a) * ctx.blockZ();
        return signed ? v : Math.abs(v);
    }

    @Override
    public double minValue() { return signed ? -1.0E8 : 0.0; }

    @Override
    public double maxValue() { return 1.0E8; }

    @Override
    public KeyDispatchDataCodec<? extends DensityFunction> codec() { return KEY_CODEC; }
}
